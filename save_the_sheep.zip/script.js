score = 0
cross = true


var audiodye=new Audio('dye.mp3');
var audiojump=new Audio('jump.mp3');




document.onkeydown = function (e) {
    console.log("key code is: ", e.key);
    if (e.key === 'ArrowUp') {
        hero = document.querySelector('.hero');
        hero.classList.add('animateHero');
        audiojump.play();
        setTimeout(() => {
            hero.classList.remove('animateHero')
        }, 700);
    }
    if (e.key === 'ArrowRight') {
        hero = document.querySelector('.hero');
        hx = parseInt(window.getComputedStyle(hero, null).getPropertyValue('left'))
        hero.style.left = hx + 100 + "px";
    }
    if (e.key === 'ArrowLeft') {
        hero = document.querySelector('.hero');
        hx = parseInt(window.getComputedStyle(hero, null).getPropertyValue('left'))
        hero.style.left = hx - 100 + "px";
    }
};
setInterval(() => {
    hero = document.querySelector('.hero')
    gameover = document.querySelector('.gameover')
    villain = document.querySelector('.villain')

    hx = parseInt(window.getComputedStyle(hero, null).getPropertyValue('left'))
    hy = parseInt(window.getComputedStyle(hero, null).getPropertyValue('top'))

    vx = parseInt(window.getComputedStyle(villain, null).getPropertyValue('left'))
    vy = parseInt(window.getComputedStyle(villain, null).getPropertyValue('top'))

    calx = Math.abs(hx - vx)
    caly = Math.abs(hy - vy)


    if (calx < 100 && caly < 80) {
        audiodye.play()
        setTimeout(() => {
            audiodye.pause()
        }, 1000);
        gameover.innerHTML = "Game Over";
        villain.classList.remove('vmove');
        hero.classList.remove('animateHero');
    }

    else if (calx < 130 && cross) {
        score += 1
        updatescore(score)
        cross = false
        setTimeout(() => {
            cross = true
        }, 1000);
        setTimeout(() => {
            aniduration = parseFloat(window.getComputedStyle(villain, null).getPropertyValue('animation-duration'))
            newduration = aniduration - 0.1;
            villain.style.animationDuration = newduration + 's';
        }, 500);


    }
}, 10);

function updatescore(score) {
    scorecount.innerHTML = "score: " + score
}

